<?php

interface WPML_End_User_Info {
	/**
	 * @return array
	 */
	public function to_array();
}
