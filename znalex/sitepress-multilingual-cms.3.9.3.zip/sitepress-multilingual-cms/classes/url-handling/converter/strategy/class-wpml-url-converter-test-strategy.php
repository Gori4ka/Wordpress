<?php

class WPML_URL_Converter_Test_Strategy extends WPML_URL_Converter_Abstract_Strategy {
	public function get_lang_from_url_string( $url ) {
		return null;
	}

	public function convert_url_string( $source_url, $lang ) {
		return null;
	}

	public function get_home_url_relative( $url, $lang ) {
		return null;
	}
}